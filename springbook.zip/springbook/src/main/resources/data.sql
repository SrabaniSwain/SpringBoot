create table book(id INT primary key,title varchar(50),auther varchar(50),price decimal,publicationDate date);
insert into book values(101,'NCRT','Udit',5000,'1990-12-12');
insert into book values(102,'Python','Miki',500,'1991-12-12');
insert into book values(103,'java','Campa',4000,'1992-12-12');

 commit;
-- select * from book;
-- delete from book;