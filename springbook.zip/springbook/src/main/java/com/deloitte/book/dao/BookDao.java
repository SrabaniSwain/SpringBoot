package com.deloitte.book.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.deloitte.book.enity.Book;
@Repository
public interface BookDao {
	int insertBook(Book b);
	public abstract List<Book> getBooks();
	public abstract Book getBookById(int bookId);
	public abstract int updateBook(Book b);
	public abstract int deleteBook(int bookid);
}
