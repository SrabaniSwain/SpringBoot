package com.deloitte.book.enity;

import java.time.LocalDate;

public class Book {

	private int id;
	private String title;
	private String auther;
	private double price;
	private LocalDate publicationDate;
	
	
	public Book() {
		super();
	}
	public Book(int id, String title, String auther, double price, LocalDate publicationDate) {
		super();
		this.id = id;
		this.title = title;
		this.auther = auther;
		this.price = price;
		this.publicationDate = publicationDate;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", auther=" + auther + ", price=" + price + ", publicationDate="
				+ publicationDate + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuther() {
		return auther;
	}
	public void setAuther(String auther) {
		this.auther = auther;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(LocalDate publicationDate) {
		this.publicationDate = publicationDate;
	}
	
	
	
	
}
