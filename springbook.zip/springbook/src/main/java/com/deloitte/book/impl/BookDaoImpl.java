package com.deloitte.book.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.deloitte.book.dao.BookDao;
import com.deloitte.book.enity.Book;
@Repository
public class BookDaoImpl implements BookDao{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int insertBook(Book b) {
		String insertQuery = "insert into book values("+b.getId()+",'"+b.getTitle()+"','"+b.getAuther()+"',"
				+b.getPrice()+",'"+b.getPublicationDate()+"');";
		return jdbcTemplate.update(insertQuery);
	}

	@Override
	public List<Book> getBooks() {
		return jdbcTemplate.query("select * from book",
				BeanPropertyRowMapper.newInstance(Book.class));
		
	}

	@Override
	public Book getBookById(int bookId) {
		
		return jdbcTemplate.queryForObject("select * from book where id=?",
				BeanPropertyRowMapper.newInstance(Book.class),bookId );
	}

	@Override
	public int updateBook(Book book) {
	
		return jdbcTemplate.update("update book set title=?,auther=?,price=?,publicationDate=? where id=?",new Object[] { book.getTitle(),book.getAuther(),book.getPrice(),book.getPublicationDate(),book.getId()});
	}

	@Override
	public int deleteBook(int bookid) {
		return jdbcTemplate.update("delete from book where id=?",new Object[] { bookid});

		
	}

}
