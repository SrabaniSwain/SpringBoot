package com.deloitte.book;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.deloitte.book.dao.BookDao;
import com.deloitte.book.enity.Book;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext appContext =SpringApplication .run(Application.class, args);
		BookDao b = appContext.getBean(BookDao.class);
		l:while(true)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("1 for add a new Book");
		System.out.println("2 for List of all book");
		System.out.println("3 for Get book by id");
		System.out.println("4 for update a book");
		System.out.println("5 for delete  a book");
		System.out.println("6 Exit");
		System.out.println("Enter your choice");
		int n=sc.nextInt();
		switch(n) 
		{
		case 1:
			LocalDate date = LocalDate.of(2023, 2, 5);
			Book b1=new Book(15,"Java","Badri",6000,date);
			int count=b.insertBook(b1);
			System.out.println(count+"record(s)inserted sucessfully");
			break;
		case 2 :
		List<Book> books = b.getBooks();
		for(Book book :books) {
			System.out.println(book);
		
		}
		break;
		case 3 :
			System.out.print("Enter Your User id");
			int id=sc.nextInt();
			Book book = b.getBookById(id);
			System.out.println(book);
			break;
		case 4:
			System.out.print("Enter Your User id");
			 id=sc.nextInt();
			 System.out.print("Enter Your User id");
			LocalDate date2 = LocalDate.of(2023, 2, 6);
			Book bo=new Book(15,"dotnet","Champa",6000,date2);
			int count1=b.updateBook(bo);
			System.out.println(count1+"record is update");
			break;
		case 5 :
		  int count4= b.deleteBook(14);
		 System.out.println(count4+"record is deleted");
		 break;
		case 6:
			break l;
			
		}
	}
		 
		 
	}
	

}
